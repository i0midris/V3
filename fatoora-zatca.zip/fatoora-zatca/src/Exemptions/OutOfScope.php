<?php

namespace Bl\FatooraZatca\Exemptions;

class OutOfScope
{
    const DEFAULT_CODE = 'VATEX-SA-OOS';
}

<?php

namespace Bl\FatooraZatca\Classes;

class DocumentType
{
    const SIMPILIFIED = '0200000';
    const STANDARD    = '0100000';
}

<?php

 return [
     'categories' => 'الأصناف',
     'manage_your_categories' => 'إدارة الأصناف الخاصة بك',
     'all_your_categories' => 'كل أصنافك',
     'category' => 'الصنف',
     'category_name' => 'إسم الصنف',
     'code' => 'رمز الصنف',
     'add_as_sub_category' => 'إضافة إلى الصنف الفرعي',
     'select_parent_category' => 'حدد الصنف الرئيسي',
     'added_success' => 'تمت إضافة الصنف بنجاح',
     'updated_success' => 'تم تحديث الصنف بنجاح',
     'deleted_success' => 'تم حذف الصنف بنجاح',
     'add_category' => 'إضافة صنف',
     'edit_category' => 'تعديل صنف',
 ];

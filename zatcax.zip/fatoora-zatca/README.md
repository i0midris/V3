# Fatoora Zatca V1.5

This package handle the phase 2 of the zakat and income authority in the saudi arabia, addition to it's based on native php so it can work on any system based on php or any framework like: (Laravel - Symfony - CodeIgniter - Yii - Zend Framework - CakePHP) 

### The package handle 3 environments:
- local.
- simulation.
- production.

> **_Note:_** If you have any questions feel free to contact me on WhatsApp: [+201270115241](https://wa.me/201270115241) or [abdelrahmangamal990@gmail.com](mailto:abdelrahmangamal990@gmail.com).

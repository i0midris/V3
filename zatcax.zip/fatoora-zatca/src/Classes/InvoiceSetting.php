<?php

namespace Bl\FatooraZatca\Classes;

class InvoiceSetting
{
    const B2C = 0100;
    const B2B = 1000;
    const ALL = 1100;
}

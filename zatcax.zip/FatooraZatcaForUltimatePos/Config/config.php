<?php

return [
    'name' => 'FatooraZatcaForUltimatePos',
    'module_version' => '1.0',
    'auto_reporting' => false,
];

<?php

namespace Modules\FatooraZatcaForUltimatePos\Exceptions;

use Exception;

class ZatcaException extends Exception
{
    //
}

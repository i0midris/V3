<?php

return [
    'connector_module' => 'Connector Module',
    'connector' => 'Connector',
    'create_client' => 'Create Client',
    'client_secret' => 'Client secret',
    'clients' => 'Clients',
    'documentation' => 'Documentation',
    'regenerate_doc' => 'Regenerate',
];

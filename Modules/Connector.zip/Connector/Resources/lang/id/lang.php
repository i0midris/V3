<?php

return [
    'connector_module' => 'Modul Konektor',
    'connector' => 'Konektor',
    'create_client' => 'Buat Klien',
    'client_secret' => 'Rahasia klien',
    'clients' => 'Klien',
    'documentation' => 'Dokumentasi',
];

<?php

return [
    'name' => 'Project',
    'module_version' => '3.0',
    'pid' => 5,
];
